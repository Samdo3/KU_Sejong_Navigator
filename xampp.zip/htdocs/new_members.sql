-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- 생성 시간: 23-11-22 16:03
-- 서버 버전: 10.4.28-MariaDB
-- PHP 버전: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 데이터베이스: `new_members`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `building_table`
--

CREATE TABLE `building_table` (
  `b_id` int(11) NOT NULL,
  `b_name` varchar(20) NOT NULL,
  `b_gps` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 테이블의 덤프 데이터 `building_table`
--

INSERT INTO `building_table` (`b_id`, `b_name`, `b_gps`) VALUES
(1, '과학기술2관', '36.610867, 127.287026'),
(2, '과학기술1관', '36.609830, 127.284742'),
(3, '가속기ICT융합관', '36.608910, 127.283600'),
(4, '산학협력관', '36.609276, 127.284491'),
(5, '농심국제관', '36.609330, 127.2885545'),
(6, '공공정책관', '36.611312, 127.288213'),
(7, '석원경상관', '36.611085, 127.289770'),
(8, '문화스포츠관', '36.611095, 127.290551');

-- --------------------------------------------------------

--
-- 테이블 구조 `event_table`
--

CREATE TABLE `event_table` (
  `event_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `class_name` varchar(255) NOT NULL,
  `building_info` varchar(255) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `day` varchar(20) NOT NULL,
  `date_added` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 테이블의 덤프 데이터 `event_table`
--

INSERT INTO `event_table` (`event_id`, `user_id`, `class_name`, `building_info`, `start_time`, `end_time`, `day`, `date_added`) VALUES
(22, 1, 'ttt', '과학기술2관', '10:00:00', '01:00:00', 'Monday', '2023-11-22');

-- --------------------------------------------------------

--
-- 테이블 구조 `user_table`
--

CREATE TABLE `user_table` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 테이블의 덤프 데이터 `user_table`
--

INSERT INTO `user_table` (`user_id`, `user_name`, `user_email`, `user_password`) VALUES
(1, 'aaa', 'aaa', '698d51a19d8a121ce581499d7b701668');

--
-- 덤프된 테이블의 인덱스
--

--
-- 테이블의 인덱스 `building_table`
--
ALTER TABLE `building_table`
  ADD PRIMARY KEY (`b_id`);

--
-- 테이블의 인덱스 `event_table`
--
ALTER TABLE `event_table`
  ADD PRIMARY KEY (`event_id`),
  ADD KEY `user_id` (`user_id`);

--
-- 테이블의 인덱스 `user_table`
--
ALTER TABLE `user_table`
  ADD PRIMARY KEY (`user_id`);

--
-- 덤프된 테이블의 AUTO_INCREMENT
--

--
-- 테이블의 AUTO_INCREMENT `building_table`
--
ALTER TABLE `building_table`
  MODIFY `b_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- 테이블의 AUTO_INCREMENT `event_table`
--
ALTER TABLE `event_table`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- 테이블의 AUTO_INCREMENT `user_table`
--
ALTER TABLE `user_table`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- 덤프된 테이블의 제약사항
--

--
-- 테이블의 제약사항 `event_table`
--
ALTER TABLE `event_table`
  ADD CONSTRAINT `event_table_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_table` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
